vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Dec 2013 17:20:08 -0000
vti_extenderversion:SR|12.0.0.4518
vti_backlinkinfo:VX|edbes.com/www.jeremiahshoaf.com/selected-work/sallie-mae.html edbes.com/www.jeremiahshoaf.com/index.html edbes.com/www.jeremiahshoaf.com/about.html
